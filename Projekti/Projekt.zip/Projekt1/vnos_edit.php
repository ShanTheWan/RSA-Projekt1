<?php require_once 'povezava.php'; ?>
<!DOCTYPE html>
<html lang='sl'>
<head>
    <title>Vaja</title>
</head>
<body>
    <?php
        $i=$_GET['id_u'];
    ?>
    <h1>Urejanje podatkov</h1>

    <form action="edit_u.php" method="post">
        Name: <input type="text" name="name" placeholder="Tukaj vnesite posodobljeno ime" size="40"><br><br>
        Surname: <input type="text" name="surname" placeholder="Tukaj vnesite posodobljen priimek" size="40"><br><br>
        Mail: <input type="email" name="email" size="40"><br><br>
        Pass: <input type="password" name="pass" size="40"><br><br>
        <input type="hidden" name="id" value=".<?php echo $i; ?>">
        <input type="reset" value="Poenostavi">&nbsp;<input type="submit" name="sub" value="Pošlji"><br>
    </form>
    <?php
        
    ?>
</body>