<!DOCTYPE html>
<html lang='sl'>
<head>
    <title>Vaja</title>
</head>
<body>
    <form action="izpis.php" methode="get">
        <input type="text" name="besedilo">
        <input type="submit" value="Klikn">
    </form>
</body>